define(function (require, exports, module) {
  // 引入所需文件
  var LoadImage = require('./loadImage')
  var Sky = require('./sky')
  var Pipe = require('./pipe')
  var Bird = require('./bird')

  function Game () {
    this.ctx = document.querySelector('canvas').getContext('2d')
    // 游戏状态
    this.running = true
  }

  Game.prototype.loading = function () {
    var that = this

    var loadImage = new LoadImage()
    loadImage.load(function (imgList) {
      // 所有素材实例数组
      var loadObjList = []
      // 天空
      loadObjList.push(new Sky(that.ctx, imgList['sky'], 0, 0))
      loadObjList.push(new Sky(that.ctx, imgList['sky'], that.ctx.canvas.width, 0))
      // 管道图片
      var topImg = imgList['pipe2']
      var bottomImg = imgList['pipe1']
      // 管道
      for (var i = 0; i < 6; i++) {
        loadObjList.push(new Pipe(that.ctx, topImg, bottomImg, i * 3 * topImg.width))
      }
      // 地面
      var Land = require('./land')
      var landImg = imgList['land']
      for (i = 0; i < 4; i++) {
        loadObjList.push(new Land(that.ctx, landImg, i * landImg.width))
      }
      // 小鸟
      var bird = new Bird(that.ctx, imgList['birds'])
      loadObjList.push(bird)

      // 运动函数
      var animation = function () {
        that.ctx.clearRect(0, 0, that.ctx.canvas.width, that.ctx.canvas.height)
        that.ctx.beginPath()
        loadObjList.forEach(function (item) {
          item.draw()
        })

        // 碰到地面
        if (bird.y > that.ctx.canvas.height - landImg.height) {
          that.running = false
        }

        // 碰到天花板
        if (bird.y < 0) {
          that.running = false
        }

        // 碰到管子
        if (that.ctx.isPointInPath(bird.x, bird.y)) {
          that.running = false
        }

        if (that.running) {
          requestAnimationFrame(animation)
        }
      }
      animation()
    })
  }

  module.exports = Game
})