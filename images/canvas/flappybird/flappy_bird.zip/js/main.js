define(function (require, exports, module) {
  var Game = require('./game')
  new Game().loading()
})