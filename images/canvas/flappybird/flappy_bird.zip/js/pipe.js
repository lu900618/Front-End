define(function (require, exports, module) {

  function Pipe (ctx, topImg, bottomImg, x) {
    this.ctx = ctx
    this.topImg = topImg
    this.bottomImg = bottomImg
    this.x = x + 300
    this.speed = 3
    this.space = 150
    this.imageHeight = this.topImg.height
    this.imageWidth = this.topImg.width
    this.calHeight()
  }

  Pipe.prototype.calHeight = function () {
    var random = Math.random() * 150
    var minH = 100
    var h = random + minH
    this.topY = -this.imageHeight + h
    this.bottomY = h + this.space
  }

  Pipe.prototype.draw = function () {
    // 绘制图片
    this.ctx.drawImage(this.topImg, this.x, this.topY)
    this.ctx.drawImage(this.bottomImg, this.x, this.bottomY)

    // 绘制图片路径
    this.ctx.rect(this.x, this.topY, this.imageWidth, this.imageHeight)
    this.ctx.rect(this.x, this.bottomY, this.imageWidth, this.imageHeight)

    this.x -= this.speed
    if (this.x <= -this.topImg.width) {
      this.x += this.topImg.width * 3 * 6
    }
  }

  module.exports = Pipe
})
