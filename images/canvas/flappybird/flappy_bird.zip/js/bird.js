define(function (require, exports, module) {

  function Bird (ctx, img) {
    this.ctx = ctx
    this.img = img
    this.x = 100
    this.y = 100
    this.birdWidth = this.img.width / 3
    this.birdheight = this.img.height
    // 翅膀图片索引
    this.index = 0

    // 初始速度
    this.v0 = 0
    // 加速度
    this.acc = 0.001
    // 起始事件
    this.startTime = Date.now()
    // 允许的最大速度
    this.maxSpeed = 0.3
    // 允许旋转的最大弧度
    this.maxAngle = Math.PI / 4

    this.click()
  }

  /**
   * 点击 canvas 小鸟上升
   */
  Bird.prototype.click = function () {
    var that = this
    this.ctx.canvas.onclick = function () {
      that.v0 = -0.3
    }
  }

  Bird.prototype.draw = function () {
    // 保存初始的状态
    this.ctx.save()
    // 移动坐标原点
    this.ctx.translate(this.x, this.y)
    // 当前时间
    var currentTime = Date.now()
    var deltaTime = currentTime - this.startTime
    // 更新起始事件
    this.startTime = currentTime
    // 计算下落的高度 h = v*t+a*t*t/2
    var h = this.v0 * deltaTime + this.acc * deltaTime * deltaTime / 2
    this.y += h
    // 加速后的速度
    this.v0 += this.acc * deltaTime
    // 角度
    var angle = this.v0 / this.maxSpeed * this.maxAngle
    if (angle > this.maxAngle) {
      angle = this.maxAngle
    }
    // 小鸟下落时旋转
    this.ctx.rotate(angle)

    this.ctx.drawImage(
      this.img,
      this.index * this.birdWidth,
      0,
      this.birdWidth,
      this.birdheight,
      -this.birdWidth / 2,
      -this.birdheight / 2,
      this.birdWidth,
      this.birdheight
    )
    this.index++
    if (this.index > 2) {
      this.index = 0
    }

    // 恢复更改坐标轴之前的状态
    this.ctx.restore()
  }

  module.exports = Bird
})
