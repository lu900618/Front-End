define(function (require, exports, module) {

  /**
   * 天空
   *
   * @param {canvas.getContext} ctx 上下文对象
   * @param {Object} skyImg 图片
   * @param {Number} x 绘制的位置x
   * @param {Number} y 绘制的位置y
   */
  function Sky (ctx, skyImg, x, y) {
    this.ctx = ctx
    this.img = skyImg
    this.x = x
    this.y = y
    // 速度
    this.speed = 3
  }

  Sky.prototype.draw = function () {
    this.ctx.drawImage(this.img, 0, 0)
    this.x -= this.speed
    if (this.x <= -this.ctx.canvas.width) {
      this.x += this.ctx.canvas.width * 2
    }
  }

  module.exports = Sky
})
