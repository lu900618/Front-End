define(function (require, exports, module) {

  /**
   * 地面
   *
   * @param {any} ctx
   * @param {any} landImg
   * @param {any} x
   */
  function Land (ctx, landImg, x) {
    this.ctx = ctx
    this.img = landImg
    this.x = x
    this.y = this.ctx.canvas.height - this.img.height
    this.speed = 3
  }

  Land.prototype.draw = function () {
    this.ctx.drawImage(this.img, this.x, this.y)
    this.x -= this.speed
    if (this.x <= -this.img.width) {
      this.x += 4 * this.img.width
    }
  }

  module.exports = Land
})
