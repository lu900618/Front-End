define(function (require, exports, module) {
  /**
   * 加载所有图片
   */
  function LoadImage () {

  }

  LoadImage.prototype.load = function (callback) {
    // 所有的图片资源
    var imageList = ['birds', 'land', 'pipe1', 'pipe2', 'sky']
    // 所有的图片资源对象
    var imgObjs = {}
    // 图片资源加载的计数器
    var index = 0

    imageList.forEach(function (image) {
      var img = new Image()
      // onload 事件是异步的, 所以不能用 索引 判断是否加载完成
      img.onload = function () {
        index++
        imgObjs[image] = img
        // 判断是否所有的图片资源都已经加载成功
        if (index === imageList.length) {
          callback && callback(imgObjs)
        }
      }
      // 先写事件, 后写 src 避免 ie 低版本的兼容问题
      // 先写 src ie 低版本 onload 事件绑定不上
      img.src = `images/${image}.png`
    })
  }

  module.exports = LoadImage
})
